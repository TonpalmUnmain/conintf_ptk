from .console import ConsoleInterface

__version__ = "0.1.0"
