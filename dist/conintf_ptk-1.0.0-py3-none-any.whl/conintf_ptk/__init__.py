from .console import ConsoleInterface

__version__ = "1.0.0"
